/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | cfMesh: A library for mesh generation
   \\    /   O peration     | Author: Franjo Juretic (franjo.juretic@c-fields.com)
    \\  /    A nd           | Copyright (C) Creative Fields, Ltd.
     \\/     M anipulation  | Copyright (C) 2017 Oliver Oxtoby
-------------------------------------------------------------------------------
License
    This file is part of cfMesh.

    cfMesh is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 3 of the License, or (at your
    option) any later version.

    cfMesh is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with cfMesh.  If not, see <http://www.gnu.org/licenses/>.

Description

\*---------------------------------------------------------------------------*/

#include "polyMeshGen.H"
#include "polyMeshGenAddressing.H"
#include "demandDrivenData.H"
#include "OFstream.H"
#include "OSspecific.H"

namespace Foam
{

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

polyMeshGen::polyMeshGen(const Time& t)
:
    polyMeshGenCells(t),
    metaDict_
    (
        IOobject
        (
            "meshMetaDict",
            runTime_.constant(),
            "polyMesh",
            runTime_,
            IOobject::READ_IF_PRESENT,
            IOobject::NO_WRITE
        )
    )
{}

//- Construct from components without the boundary
polyMeshGen::polyMeshGen
(
    const Time& t,
    const pointField& points,
    const faceList& faces,
    const cellList& cells
)
:
    polyMeshGenCells(t, points, faces, cells),
    metaDict_
    (
        IOobject
        (
            "meshMetaDict",
            runTime_.constant(),
            "polyMesh",
            runTime_,
            IOobject::READ_IF_PRESENT,
            IOobject::NO_WRITE
        )
    )
{}

//- Construct from components with the boundary
polyMeshGen::polyMeshGen
(
    const Time& t,
    const pointField& points,
    const faceList& faces,
    const cellList& cells,
    const wordList& patchNames,
    const labelList& patchStart,
    const labelList& nFacesInPatch
)
:
    polyMeshGenCells
    (
        t,
        points,
        faces,
        cells,
        patchNames,
        patchStart,
        nFacesInPatch
    ),
    metaDict_
    (
        IOobject
        (
            "meshMetaDict",
            runTime_.constant(),
            "polyMesh",
            runTime_,
            IOobject::READ_IF_PRESENT,
            IOobject::NO_WRITE
        )
    )
{}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
// Destructor
polyMeshGen::~polyMeshGen()
{}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

// TODO should go in its own sub-file
void polyMeshGen::fillInCellAndPointLevels()
{
    // Set cell level for undefined cells as max of neighbouring previously 
    // set cell levels
    bool allDone = false;
    labelList newCellLevel(cellLevel_.size(), -1);
    const label protectedSetId = addCellSubset("meshProtectedCells");
    while (!allDone)
    {
        allDone = true;

        // Do a layer of cells
        const VRWGraph& cellCells = addressingData().cellCells();
        forAll(cellCells, cellI)
        {
            if (cellLevel_[cellI] == -1)
            {
                cellSubsets_[protectedSetId].addElement(cellI);
                forAllRow(cellCells, cellI, i)
                {
                    newCellLevel[cellI] = max(newCellLevel[cellI], cellLevel_[cellCells(cellI, i)]);
                }
                if (newCellLevel[cellI] == -1)
                {
                    allDone = false;
                }
            }
        }

        // Transfer the layer, ready to do the next one
        forAll(cellCells, cellI)
        {
            if (newCellLevel[cellI] != -1)
            {
                cellLevel_[cellI] = newCellLevel[cellI];
            }
        }

    }

    // Set point level for undefined points as max of surrounding cell levels
    const VRWGraph& pointCells = addressingData().pointCells();
    forAll(pointCells, pointI)
    {
        if (pointLevel_[pointI] == -1)
        {
            // Setting pointLevel to a large value to 'trick' the standard
            // OpenFOAM refiners into not refining the surrounding cells
            // (as they do not currently read the meshProtectedCells set).
            pointLevel_[pointI] = labelMax;
            //forAllRow(pointCells, pointI, i)
            //{
            //    pointLevel_[pointI] = max(pointLevel_[pointI], cellLevel_[pointCells(pointI, i)]);
            ////    cellSubsets_[protectedSetId].addElement(pointCells(pointI, i));
            //}
        }
    }
}

void polyMeshGen::read()
{
    polyMeshGenCells::read();
}

void polyMeshGen::write() const
{
    //- remove old mesh before writting
    const fileName meshDir = runTime_.path()/runTime_.constant()/"polyMesh";

    rm(meshDir/"points");
    rm(meshDir/"faces");
    rm(meshDir/"owner");
    rm(meshDir/"neighbour");
    rm(meshDir/"cells");
    rm(meshDir/"boundary");
    rm(meshDir/"pointZones");
    rm(meshDir/"faceZones");
    rm(meshDir/"cellZones");
    rm(meshDir/"meshModifiers");
    rm(meshDir/"parallelData");
    rm(meshDir/"meshMetaDict");

    // remove sets if they exist
    if (isDir(meshDir/"sets"))
    {
        rmDir(meshDir/"sets");
    }

    rm(meshDir/"cellLevel");
    rm(meshDir/"pointLevel");

    //- write the mesh
    polyMeshGenCells::write();

    //- write meta data
    OFstream fName(meshDir/"meshMetaDict");

    metaDict_.writeHeader(fName);
    metaDict_.writeData(fName);
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
